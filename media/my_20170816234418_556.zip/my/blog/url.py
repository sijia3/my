# -*- coding: utf-8 -*-
from django.conf.urls import url,include
import blog.views



urlpatterns = [
    url(r'^$', blog.views.login,name='blog_login'),
    url(r'^login/$',blog.views.login,name='blog_login'),
    url(r'^login_out/$',blog.views.login_out,name='blog_login_out'),
    url(r'^register/$',blog.views.register,name='blog_register'),
    url(r'^imformation/$',blog.views.user_imformation,name='user_imfor'),
    url(r'^name_change/$',blog.views.username_change,name='name_change'),
    url(r'^password_change/$',blog.views.password_change,name='password_change'),
    url(r'^password_lost/$',blog.views.password_lost,name='password_lost'),
    url(r'^change/$',blog.views.change,name='user_change'),

]
