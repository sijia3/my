# from django.test import TestCase
# from blog.models import BlogsPost,Tag,UserProfile
# from blog.views import th
# # Create your tests here.
# t = th.get_blog_tags(1)
# print t
