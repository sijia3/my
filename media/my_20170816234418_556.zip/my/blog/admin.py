# -*- coding: utf-8 -*-
from django.contrib import admin
# from blog.models import BlogsPost,Tag
# from blog.models import UserProfile
from blog.models import *
# from django.contrib.auth.models import User
# Register your models here.


class BlogPostAdmin(admin.ModelAdmin):
    list_display = ('title','content','publish_time','update_time','read_num')
    # list_editable = ['content','read_num']
    # filter_horizontal = ('tag',)
admin.site.register(BlogsPost,BlogPostAdmin)

class TagAdmin(admin.ModelAdmin):
    list_display = ('tag_name','create_time')

admin.site.register(Tag,TagAdmin)



class UserProfileInline(admin.StackedInline):
    model = UserProfile
    verbose_name = '用户信息'

class UserAdmin(admin.ModelAdmin):
    inlines = (UserProfileInline,)


admin.site.unregister(User)
admin.site.register(User,UserAdmin)
admin.site.register(UserProfile)