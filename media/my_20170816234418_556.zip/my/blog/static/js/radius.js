$(document).ready(function(){ 	
						   
						   
	// radius Box
	$('.menu_nav ul li a').css({"border-radius": "6px", "-moz-border-radius":"6px", "-webkit-border-radius":"6px"});
	// end radius Box
	 
});	