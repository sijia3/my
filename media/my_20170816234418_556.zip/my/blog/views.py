#coding=utf-8
from django.shortcuts import render
from blog.models import BlogsPost,Tag,UserProfile
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.core.paginator import Paginator
from django.http import HttpResponseRedirect
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
from django.contrib.auth import authenticate
import time
# Create your views here.
class TagsHelper:            #标签辅助类
    def __init__(self):
        self.tags = Tag.objects.all()
        self.count = len(self.tags)
    def get_information(self):
        tag_blog = []
        for i in Tag.objects.all():
            t = {}
            t['id'] = i.id
            t['tag_name'] = i
            t['num'] = len(i.t_blog.all())
            tag_blog.append(t)
        return tag_blog
    def get_blog_tags(self,id):
        blog_to_tags = []
        blog = BlogsPost.objects.get(id=id)
        tagged = blog.tag.all()
        for i in tagged:
            t = {}
            t['id'] = i.id
            t['tag_name'] = i
            t['num'] = len(i.t_blog.all())
            blog_to_tags.append(t)
        return blog_to_tags
th = TagsHelper()

#页码辅助函数
def get_pages(request,object_lists):
    current_page = request.GET.get('page',1)     #获得当前页数，默认为1
    paginator = Paginator(object_lists,3)         #得到一个分页后的对象
    object_lists = paginator.page(current_page)   #得到当前页面的blog列表
    current = object_lists.number
    page_all = paginator.num_pages
    page_range = []
    if page_all<5:
        page_range = paginator.page_range
    else:
        page_range +=[1,page_all]
        page_range += [current-1, current, current+1]
        if current == 1 or current == page_all:
            page_range += [current+2, current-2]

        #去掉超出范围的页码
        page_range = filter(lambda x: x>=1 and x<=page_all, page_range)

        #排序去重
        page_range = sorted(list(set(page_range)))
        # page_range.insert(1,'...')
        t = 1             #这是一个坑
        for i in range(1,len(page_range)):
            # print page_range[i],page_range[i-1]
            if page_range[t]-page_range[t-1]>1:
                page_range.insert(t,'...')
                # print page_range
                t = t+1
            t = t+1


        # print page_range


    paginator.page_range_ex = page_range
    return object_lists,paginator


def index(request,user=None):
    data = {}
    current_tag = request.GET.get('tag')
    blogs = BlogsPost.objects.all().order_by('-publish_time')    #按时间排序
    if current_tag:               #如果有这个标签
        tag = Tag.objects.filter(id = current_tag)
        blogs = tag[0].t_blog.all()
        data["current_tag"] = current_tag       #增加标签的tag，使多页page能正常显示
    blogs,pages = get_pages(request,blogs)
    data["blogs"] = blogs
    data["pages"] = pages       #总页码数
    data["tags"] = th.get_information()
    if request.user.is_authenticated():
        data['username'] = request.user
    # if user:
    #     data["username"] = user
    return render_to_response('index.html',data)


def blog_show(request,id):
    user = request.user
    data ={}
    data['user'] = user
    blog = BlogsPost.objects.get(id=id)
    data['tagged'] = th.get_blog_tags(id)
    blog.read_num += 1
    blog.save()
    data['blog'] = blog
    pre_blog = BlogsPost.objects.filter(id__gt=blog.id).order_by('id')
    next_blog = BlogsPost.objects.filter(id__lt=blog.id).order_by('-id')

    #取第1条记录
    if pre_blog.count() > 0:
        data['pre_blog'] = pre_blog[0]
    else:
        data['pre_blog'] = None

    if next_blog.count() > 0:
        data['next_blog'] = next_blog[0]
    else:
        data['next_blog'] = None
    if request.user.is_authenticated():
        data['username'] = request.user
    data["tags"] = th.get_information()

    return render_to_response('blog_show.html',data,context_instance=RequestContext(request))
    # return render(request, 'blog_single.html', data)


def search(request):
    data = {}
    current_tag = request.GET.get('tag')
    key = request.GET['key']
    if not key:
        return index(request)
    blogs = BlogsPost.objects.filter(title__contains=key)
    blogs,pages = get_pages(request,blogs)

    if request.user.is_authenticated():
        data['username'] = request.user
    if current_tag:               #如果有这个标签
        tag = Tag.objects.filter(id = current_tag)
        blogs = tag[0].t_blog.all()
        data["current_tag"] = current_tag       #增加标签的tag，使多页page能正常显示
    data['blogs'] = blogs
    data['pages'] = pages
    data["tags"] = th.get_information()
    data['key'] = key
    return render_to_response('blog_search(1).html',data,context_instance=RequestContext(request))

def login(request):
    data = {}
    data["tags"] = th.get_information()
    if request.method == 'POST':
        username = (request.POST.get('username'))
        password = (request.POST.get('password'))
        user = authenticate(username=username,password=password)
        if user is not None:
            auth_login(request, user)
            return HttpResponseRedirect('/blog')
        else:
            data["error"] = "账号或者密码出错！"
            return render_to_response('blog_login(1).html',data,context_instance=RequestContext(request))
    else:
        return render_to_response('blog_login(1).html',data,context_instance=RequestContext(request))

def login_out(request):
    auth_logout(request)
    return HttpResponseRedirect('/blog')   #request.META.get('HTTP_REFERER', '/')

def register(request):
    data = {}
    data["tags"] = th.get_information()
    if request.method == 'POST':
        username = (request.POST.get('username'))
        password1 = (request.POST.get('password1'))
        password2 = (request.POST.get('password2'))
        user = User.objects.filter(username=username)
        if user:
            data["error"] = "用户名存在！！重新选择您的用户名。"
            return render_to_response('blog_register(1).html',data,context_instance=RequestContext(request))

        if password1 != password2:
            data["error"] = "两次输入的密码不同,请重新输入"
            return render_to_response('blog_register(1).html',data,context_instance=RequestContext(request))
        # user = User()
        # user.username = username
        # user.password = password1
        # user.save()
        user = User.objects.create_user(username=username,password=password1)
        user.save()
        profile = UserProfile()
        profile.user_id = user.id
        profile.save()
        data["error"] = "注册帐号成功！"
        return render_to_response('blog_register(1).html',data,context_instance=RequestContext(request))
        # user = authenticate(username=username,password=password1)

    return render_to_response('blog_register(1).html',data)

def change(request):
    user = request.user
    data = {}
    data["username"] = user.username
    data["password"] = user.password
    if request.method == "POST":
        u_name = request.POST.get('username')
        u_password = request.POST.get('password')
        # if User.objects.filter(username=u_name):
        #     data["error"] = "存在该用户名！"
        #     return render_to_response('user_change.html',data,context_instance=RequestContext(request))
        user.username = u_name
        user.save()
        if u_password:     #如果用户修改密码的话：
            user.set_password(u_password)
            user.save()
            user = authenticate(username=u_name,password=u_password)   #重新登录
            if user is not None:
                auth_login(request, user)
                return HttpResponseRedirect('/blog',time.sleep(3))
        return HttpResponseRedirect('/blog',time.sleep(3))
    return render_to_response('user_change.html',data)

def user_imformation(request):
    user = request.user
    data = {}
    data["tags"] = th.get_information()
    data["username"] = user.username
    data["password"] = user.password
    data["last_login"] = user.last_login
    data["data_joined"] = user.date_joined
    return render_to_response('user_imformation(1).html',data,context_instance=RequestContext(request))


def username_change(request):
    user = request.user
    data = {}
    data["username"] = user.username
    data["password"] = user.password
    if request.method == "POST":
        u_name = request.POST.get('username')
        user.username = u_name
        if User.objects.filter(username=u_name):
            data['error'] = "用户名存在！！"
            return render_to_response('username_change(1).html',data,context_instance=RequestContext(request))
        user.save()
        data['error'] = "修改成功！！"
        data["username"] = user.username
        data["password"] = user.password
        return render_to_response('username_change(1).html',data,context_instance=RequestContext(request))
    return render_to_response('username_change(1).html',data)

def password_change(request):
    user = request.user
    data = {}
    data["username"] = user.username
    data["password"] = user.password
    if request.method == "POST":
        u_password = request.POST.get('password')
        user.set_password(u_password)
        user.save()
        user = authenticate(username=user.username,password=u_password)   #重新登录
        auth_login(request, user)
        return HttpResponseRedirect('/blog',time.sleep(3))
    return render_to_response('password_change(1).html',data)

def password_lost(request):
    data = {}
    if request.method == "POST":
        username = request.POST.get('username')
        password1 = request.POST.get('password1')
        user = User.objects.get(username=username)
        if user:
            user.set_password(password1)
            user.save()
            user = authenticate(username=user.username,password=password1)   #重新登录
            auth_login(request, user)
            data['error'] = "密码重置完成，正在为你跳转。。"
            return HttpResponseRedirect('/blog',time.sleep(3))
        return render_to_response('password_lost(1).html',data,context_instance=RequestContext(request))
    return render_to_response('password_lost(1).html',data)




def helloParams(request):
    p1 = request.GET.get('p1')
    p2 = request.GET.get('p2')
    return HttpResponse("p1 = "+p1+"p2 = "+p2)