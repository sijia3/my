# -*- coding: utf-8 -*-
"""my URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url,include
from django.contrib import admin
from werobot.contrib.django import make_view
import grade.views
from wechat.robot import robot
import blog.views
import my.settings
import django.views
urlpatterns = [
    url(r'^admin/', admin.site.urls),
    # url(r'^$', grade.views.login_user),   #主网页，用来查成绩
    url(r'^$', blog.views.index,name='index'),
    url(r'^cj', grade.views.cj),          #成绩查询登陆跳转页面
    url(r'^robot/$', make_view(robot)),   #微信机器人
    url(r'^blog/$',blog.views.index,name='index'),    #博客
    url(r'^blog/(?P<id>\d+)/$', blog.views.blog_show, name='detailblog'),  #单个博客显示
    url(r'^blog/search/$',blog.views.search,name='search'),
    url(r'^blog/comments/', include('django_comments.urls')),
    url(r'^user/',include('blog.url')),
    url(r'^ueditor/',include('DjangoUeditor.urls' )),
    url(r'^media/(?P<path>.*)$', django.views.static.serve, {'document_root': my.settings.MEDIA_ROOT}),
    # url(r'^ckeditor/', include('ckeditor.urls')),
    url(r'^plist/$',blog.views.helloParams),
]
