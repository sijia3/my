# from __future__ import unicode_literals
# from django.contrib import admin
# from django.db import models
#
# # Create your models here.
# class student(models.Model):
#     open_id = models.CharField(max_length=30)
#     name = models.CharField(max_length=30)
#     grades = models.CharField(max_length=30)
#
# class student_admin(admin.ModelAdmin):
#     list_display = ('name','grades')
#
# admin.site.register(student,student_admin)