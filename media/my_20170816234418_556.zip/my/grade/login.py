#-*-coding:utf-8-*-
import requests
from bs4 import BeautifulSoup
import re

class get_messages():           #得到用户所有信息的类
    def __init__(self):
        self.url = 'http://100.fosu.edu.cn/default2.aspx'
        self.headers =  {'User-Agent':"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.101 Safari/537.36"}
    def login_100net(self,user,pw):     # 进行登录的函数，爬取信息的函数
        global s
        s = requests.Session()
        r = s.get(self.url)
        #使用bs获取viewstate
        soup = BeautifulSoup(r.text,'html.parser')
        text = soup.find('form').find('input',type = "hidden")
        #构建上传数据
        rb = u"学生".encode('gb2312','replace')
        bu = u"登录".encode('gb2312','replace')

        data = {
            "__VIEWSTATE" : text['value'],
            "yh" : user,
            "kl" : pw,
            "RadioButtonList1" : rb,
            "Button1" : bu,
            "CheckBox1" : "on"
            }
        response = s.post(self.url,data = data, headers = self.headers)
        cjurl = "http://100.fosu.edu.cn/xscj.aspx?xh="+user
        headers = {
            'Referer' : "http://100.fosu.edu.cn/xsleft.aspx?flag=xxcx",
            'User-Agent':"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.113 Safari/537.36"
            }
        r_cj = s.get(cjurl,headers = headers)
        if r_cj.text == "<script languange='javascript'>window.parent.location='';</script>":
            return False                      #密码错误时进行提示
        choice = [
            {  "a" : "2016-2017",
               "b" : "2"},
            {  "a" : "2016-2017",
               "b" : "1" },
            {  "a" : "2015-2016",
               "b" : "2" },
            {  "a" : "2015-2016",
               "b" : "1" },
            {  "a" : "2014-2015",
               "b" : "2"},
            {  "a" : "2014-2015",
               "b" : "1" },
        ]
        term_list = []
        for i in choice:
            pattern = "<td>"+i['a']+"</td><td>"+i['b']+"</td><td>(.*?)</td><td>(.*?)</td><td>(.*?)</td><td>(.*?)</td><td>(.*?)</td><td>&(.*?);</td><td>(.*?)</td><td>(.*?)</td><td>(.*?)</td><td>(.*?);</td><td>(.*?)</td><td>(.*?)</td><td>(.*?)</td>"
            m_tr =  re.findall(pattern,r_cj.text)
            m_tr = m_tr[0:]
            if m_tr:
                pass
            else:
                break
            t = {}
            t['term'] = i['a']+"第"+i['b']+"学期"
            if i['a'] == '2016-2017' and i['b'] == '2':
                t['flag'] = 'active'
            else:
                t['flag'] = ''
            t['lists'] =[]
            for line in m_tr:
                line = list(line)
                s = {}
                s['km'] = line[0]
                s['cj'] = line[8]
                t['lists'].append(s)
            term_list.append(t)
        # print term_list
        return term_list


    def get_user_information(self,user,pw):
        s = requests.Session()
        r = s.get(self.url)
        #使用bs获取viewstate
        soup = BeautifulSoup(r.text,'html.parser')
        text = soup.find('form').find('input',type = "hidden")
        #构建上传数据
        rb = u"学生".encode('gb2312','replace')
        bu = u"登录".encode('gb2312','replace')

        data = {
            "__VIEWSTATE" : text['value'],
            "yh" : user,
            "kl" : pw,
            "RadioButtonList1" : rb,
            "Button1" : bu,
            "CheckBox1" : "on"
            }
        response = s.post(self.url,data = data, headers = self.headers)
        user_inf_url = "http://100.fosu.edu.cn/xstop.aspx"          #得到学生信息
        headers = {
            'Referer' : "http://100.fosu.edu.cn/xsmainfs.aspx?xh=20150390109",
            'User-Agent':"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.113 Safari/537.36"
            }
        r_cj = s.get(user_inf_url,headers = headers)
        # print r_cj.text
        xm = r'<span id="lbXM">(.*?)</span>'
        zy = r'<span id="lbBJMC">(.*?)</span>'
        xh = r'<span id="lbXH">(.*?)</span>'
        xm =  re.findall(xm,r_cj.text)
        zy =  re.findall(zy,r_cj.text)
        xh =  re.findall(xh,r_cj.text)
        user_information = {
            'xm': xm[0],
            'zy': zy[0],
            'xh': xh[0],
        }
        return user_information


get_messages = get_messages()


