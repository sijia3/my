# -*- coding: utf-8 -*-
from django.shortcuts import render
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.template import RequestContext
from django.shortcuts import render_to_response
from login import get_messages
# Create your views here.
import sys
reload(sys)
sys.setdefaultencoding( "utf-8" )
def login_user(request):
    if request.method =='GET':
        # return render_to_response('login.html',context_instance=RequestContext(request))
        return render(request,'login.html')
    else:
        global user,pw
        user = str(request.POST.get('user'))        #只能用一次，，，如何解决
        pw = str(request.POST.get('pw'))
        # print pw
        flag = get_messages.login_100net(user,pw)                #学生成绩的所有信息
        if flag == False:
            return render(request,'login.html',{"error":"账号或密码出错，请重新输入!!"})
        return HttpResponseRedirect('/cj')        #重定向到别的网页。
#YEHL1426468134
def cj(request):
    term_list = get_messages.login_100net(user,pw)                #学生成绩的所有信息
    user_information = get_messages.get_user_information(user,pw)
    for i in user_information.values():
        print i,
    print "\n"
    return render(request,'cj.html',{'term_list':term_list,"user_information":user_information})